document.getElementById('contact-form').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the default form submission

    emailjs.sendForm('service_fmauj3u', 'template_9tdumq6', this) // Replace 'your-template-id' with your actual template ID.
        .then(function() {
            alert('Message sent successfully!');
            document.getElementById('contact-form').reset(); // Optional: Reset form after submission
        }, function(error) {
            alert('Failed to send message: ' + JSON.stringify(error));
        });
});
